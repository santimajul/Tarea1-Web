const personas = [];
const filtrados = [];
const rowsPerPage = 5;
let currentPage = 1;
let isFiltered = false;

function agregarDatos() {
    // Obtener los valores de los campos de texto
    const nombre = document.getElementById('nombre').value;
    const apellido = document.getElementById('apellido').value;

    // Verificar que ambos campos tengan valores
    if (nombre && apellido) {
        personas.push({nombre, apellido});
        isFiltered = false; // Resetear el estado del filtro al agregar nuevos datos
        mostrarDatos();
        document.getElementById('nombre').value = '';
        document.getElementById('apellido').value = '';
    } else {
        alert('Por favor, complete ambos campos.');
    } 
}

function mostrarDatos() {
    const tbody = document.getElementById('tbody');
    tbody.innerHTML = '';

    const dataToShow = isFiltered ? filtrados : personas; // Mostrar los datos filtrados si están en modo filtrado

    const start = (currentPage - 1) * rowsPerPage;
    const end = start + rowsPerPage;
    const paginatedData = dataToShow.slice(start, end);

    paginatedData.forEach((persona, index) => {
        let row = document.createElement('tr');

        let celdaNombre = document.createElement('td');
        celdaNombre.textContent = persona.nombre;

        let celdaApellido = document.createElement('td');
        celdaApellido.textContent = persona.apellido;

        const celdaAccion = document.createElement('td');
        const botonEliminar = document.createElement('button');
        botonEliminar.className = 'x';
        botonEliminar.textContent = 'X';
        celdaAccion.style.width = '30px';
        celdaAccion.style.borderRight = '1px solid #4b3832';
        celdaAccion.style.borderLeft = 'none';
        botonEliminar.onclick = function() {
            if (isFiltered) {
                const originalIndex = personas.indexOf(filtrados[start + index]);
                personas.splice(originalIndex, 1); // Eliminar del array original
                filtrados.splice(start + index, 1); // Eliminar del array filtrado
            } else {
                personas.splice(start + index, 1);
            }
            mostrarDatos(); // Actualiza la tabla después de eliminar la fila
        };

        celdaAccion.appendChild(botonEliminar);

        // Agregar las celdas a la fila
        row.appendChild(celdaNombre);
        row.appendChild(celdaApellido);
        row.appendChild(celdaAccion);

        // Agregar la fila a la tabla
        tbody.appendChild(row);
    });

    mostrarPaginacion(dataToShow);
}

function mostrarPaginacion(dataToShow) {
    const pagination = document.getElementById('pagination');
    pagination.innerHTML = '';

    const totalPages = Math.ceil(dataToShow.length / rowsPerPage);

    for (let i = 1; i <= totalPages; i++) {
        const pageButton = document.createElement('button');
        pageButton.textContent = i;
        pageButton.className = i === currentPage ? 'active' : '';
        pageButton.onclick = function() {
            currentPage = i;
            mostrarDatos();
        };
        pagination.appendChild(pageButton);
    }
}

function filtrarDatos() {
    const search = document.getElementById('search').value.trim().toLowerCase();
    filtrados.length = 0; // Vaciar el array filtrados

    if (search) {
        personas.forEach(persona => {
            if (persona.nombre.toLowerCase() === search || persona.apellido.toLowerCase() === search) {
                filtrados.push(persona);
            }
        });

        isFiltered = true;
        currentPage = 1; // Reiniciar la paginación al filtrar
        mostrarDatos();
    } else {
        isFiltered = false;
        mostrarDatos(); // Mostrar todos los datos si no hay búsqueda
    }
}

